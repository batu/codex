#ifndef _IRC_PROTO_H_
#define _IRC_PROTO_H_

typedef enum {
    ERR_INVALID = 1,
    ERR_NOSUCHNICK = 401,
    ERR_NOSUCHCHANNEL = 403,
    ERR_NORECIPIENT = 411,
    ERR_NOTEXTTOSEND = 412,
    ERR_UNKNOWNCOMMAND = 421,
    ERR_ERRONEOUSNICKNAME = 432,
    ERR_NICKNAMEINUSE = 433,
    ERR_NONICKNAMEGIVEN = 431,
    ERR_NOTONCHANNEL = 442,
    ERR_NOLOGIN = 444,
    ERR_NOTREGISTERED = 451,
    ERR_NEEDMOREPARAMS = 461,
    ERR_ALREADYREGISTRED = 462,

    //added a few more and there were some mistakes in the earlier ones.
    ERR_TOOMANYCHANNELS = 405,
    ERR_NOSUCHSERVER = 402,
    ERR_CANNOTSENDTOCHAN = 404
} err_t;

typedef enum {
    RPL_NONE = 300,
    RPL_USERHOST = 302,
    RPL_LISTSTART = 321,
    RPL_LIST = 322,
    RPL_LISTEND = 323,
    RPL_WHOREPLY = 352,
    RPL_ENDOFWHO = 315,
    RPL_NAMREPLY = 353,
    RPL_ENDOFNAMES = 366,
    RPL_MOTDSTART = 375,
    RPL_MOTD = 372,
    RPL_ENDOFMOTD = 376
} rpl_t;

extern void handle_line(char *line, int clientFD);
//void handle_line(char *line);

#endif /* _IRC_PROTO_H_ */
