 package impl;

import java.util.HashSet;
import java.util.Set;

import api.Card;
import api.Card.Value;
import api.Hand;

public class BlackJackHand extends Hand{

	protected int handTotal = 0;
	
	public BlackJackHand(){
		cards = new HashSet<Card>();
	}
	
	public void collectHand(){
		cards.clear();
	}
	
	
	// I dont see the function in the Hand.java.
	@Override
	public int compareTo(Hand arg0) {
		// TODO Auto-generated method stub
		
		return 0;
	}

	@Override
	public boolean isValid() {
		// TODO Auto-generated method stub
		if(handTotal <= 21){
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean isWinner() {
		// TODO Auto-generated method stub
		
		if(handTotal == 21){
			return true;
		}else{
			return false;
		}

	}

	@Override
	public int valueOf() {
		handTotal = 0;
		for (Card card : cards) {
			Value value = card.getValue();
		    handTotal = handTotal + value.getValue();
		}
		return handTotal;
	}

	
	
}