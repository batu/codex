package impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import api.Dealer;
import api.Player;
import api.Table;

public class BlackJackTable extends Table{

	
	public BlackJackTable(int numberOfPlayers) {
		// TODO Auto-generated constructor stub
		this.wagers = new HashMap<Player, Double>();
		this.players = new ArrayList<Player>();
		this.dealer = new BlackJackDealer();
		
		for (int i = 1; i != numberOfPlayers ; i++){
			String nameInput = "Player " + Integer.toString(i);
			Player player = new BlackJackPlayer(nameInput);
			players.add(player);
		}
	}
	
	@Override
	public boolean isGameOver() {
		
		if(players.isEmpty() == true){
			return true;
		}
		for(Player player: players){
			//Assuming 10 is the minimum ante.
			if( player.getMoney() >= 10){
				return false;
			}
		}
		return true;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String tableState = "";
		for(Player player: players){
			Double playerMoney = player.getMoney();
			tableState += player.getName() + " has " + Double.toString(playerMoney) + " dollars\n";
		}
		return tableState;
	}

	@Override
	protected void collectBets() {
		for(Player player: players){
			wagers.put(player, player.wager());
		}
		// TODO Auto-generated method stub
	}

	@Override
	protected void playerTurns() {
		
		while(dealer.getHand().valueOf() < 17){
			dealer.dealCard((Player) dealer);
		}
		
		for(Player player: players){
			while(player.requestCard()){
				dealer.dealCard(player);
			}
		}
	}

	@Override
	protected void playerEvaluations() {
		// TODO Auto-generated method stub
		Player toBeRemoved = null;
		int dealerHandValue = dealer.getHand().valueOf();
		for(Player player: players){
			int playerhandValue = player.getHand().valueOf();
			if(player.getHand().isWinner() ||  playerhandValue > dealerHandValue && player.getHand().isValid()){
				player.payOut(wagers.get(player));
			} else {
				if (player.getMoney() == 0){
					toBeRemoved = player;
				}
			}
		}
		players.remove(toBeRemoved);
	}
 }