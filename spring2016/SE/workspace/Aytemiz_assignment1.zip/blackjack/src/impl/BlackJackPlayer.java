package impl;
import api.Card;
import api.Hand;
import api.Player;

public class BlackJackPlayer implements Player{

	public String name;
	public double money;
	public double wagerAmount = 10;
	public Hand playerHand;
	// hand money and name
	
	public BlackJackPlayer(String nameInput){
		name = nameInput;
		money = 100;
	}
	
	
	@Override
	public int compareTo(Player o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void receive(Card card) {
		playerHand.addCard(card);
		
	}

	@Override
	public void receive(Hand hand) {
		playerHand = hand;
	}

	@Override
	public Hand getHand() {
	    
	    //Return the current hand to the caller
		return playerHand;
	}

	@Override
	public double wager() {
		// TODO Auto-generated method stub
		this.money = money - 10;
		return 10;
	}

	@Override
	public void payOut(double money) {
		this.money += money;
	}

	@Override
	public double getMoney() {
		// TODO Auto-generated method stub
		return this.money;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public boolean requestCard() {
		// TODO Auto-generated method stub
		if(playerHand.valueOf() < 17){
			return true;
		}else{
			return false;
		}
	}
	
}