package impl;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import api.Card;
import api.Dealer;
import api.Hand;
import api.Player;
import api.Card.Suit;
import api.Card.Value;
 

public class BlackJackDealer extends BlackJackPlayer implements Dealer  {

	protected Set<Card> deck = new HashSet<Card>();
	
	
	public BlackJackDealer() {
		super("Dealer");
		// TODO Auto-generated constructor stub
		for ( Suit suit : Card.Suit.values() ) {
			for (Value value : Card.Value.values()){
				Card card = new Card(value, suit);
				deck.add(card);
			}
		}
	}

	
	@Override
	public void dealCard(Player player) {
		Card card = deck.iterator().next();
		deck.remove(card);
		
		Hand playerHand = player.getHand();
		playerHand.addCard(card);
	}

	@Override
	public void dealTable(List<Player> players) {
		// TODO Auto-generated method stub
		Card card;		
		

		for (Player player : players){
			Hand playerHand = new BlackJackHand();
			for (int i = 0; i < 2; i++){
				card = deck.iterator().next();
				deck.remove(card);
				playerHand.addCard(card);	
			}		
			player.receive(playerHand);
		}
		
		this.playerHand = new BlackJackHand();
		for (int i = 0; i < 2; i++){
			card = deck.iterator().next();
			deck.remove(card);
			Hand dealerhand = getHand();
			dealerhand.addCard(card);	
		}		

		
	}

	@Override
	public void collectCards(Player player) {
		// TODO Auto-generated method stub
		
		//Collect hand not working.
		((BlackJackHand) player.getHand()).collectHand();
		
		for ( Suit suit : Card.Suit.values() ) {
			for (Value value : Card.Value.values()){
				Card card = new Card(value, suit);
				deck.add(card);
			}
		}
		
	}

	@Override
	public void collectCards(List<Player> players) {
		for(Player player: players){
			((BlackJackHand) player.getHand()).collectHand();
		}
		
		for ( Suit suit : Card.Suit.values() ) {
			for (Value value : Card.Value.values()){
				Card card = new Card(value, suit);
				deck.add(card);
			}
		}		
	}

	@Override
	public Hand getHand() {
		
		Hand dealerHand = this.playerHand;
		return dealerHand;
	}

}