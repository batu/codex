package api;

import javafx.scene.shape.Circle;

public interface Controller {
    //public void handlePlaceDisk(int row, int col);
	public void handlePlaceDisk(int row, int col);


	void handleSetWidth(int row, int col, int witdh);

}
